# NEXUS — MVP Scaffold

AI-powered personalized simulation platform for students and young adults.
This is a **working MVP skeleton**, matching the "MVP — First Build" scope
in the master spec: profile → one goal → constrained world → decisions →
simulation state → What If? branches.

## What's here

```
backend/    FastAPI app — the simulation engine + API (the real core)
frontend/   Minimal React app — profile creation + decision loop
docs/       Architecture notes matching the spec
```

**Key design principle carried over from the spec:** the AI layer
(`backend/app/simulation/narrative.py`) generates situations, but the
**simulation engine** (`backend/app/simulation/engine.py`) is the only
thing that changes numbers. This separation is intentional — see
`docs/ARCHITECTURE.md`.

## Running it

### Backend
```bash
cd backend
pip install -r requirements.txt
uvicorn app.main:app --reload
```
API docs at `http://localhost:8000/docs` (FastAPI auto-generates a full
interactive test UI — try the endpoints there first, no frontend needed).

### Frontend
```bash
cd frontend
npm install
npm run dev
```

## Getting this onto GitHub from your phone

You have three realistic options:

1. **Claude Code (mobile app)** — the most direct route. Install Claude Code,
   point it at this project, and ask it to init a git repo and push to
   GitHub. It can create the repo and push for you in one flow.

2. **GitHub mobile app / github.com in browser** — create an empty repo on
   GitHub first, then use a phone-friendly Git client (e.g. Working Copy on
   iOS, or Termux + git on Android) to `git init`, commit, and push these
   files.

3. **Manual upload** — create a new repo on github.com, then use "Add file →
   Upload files" in the web UI and drag in this folder structure. Slowest,
   but requires nothing installed.

Once it's a real repo, GitHub Codespaces (accessible from a phone browser)
gives you a full cloud dev environment for any further coding.

## Wiring in real AI

Right now `narrative.py` uses templates so the app runs with zero API keys.
When ready, replace `generate_situation()` with a real call (e.g. to the
Claude API) that takes the user's goal/skills/interests and returns a
situation + options — keep the same return shape so nothing else breaks.

## What's deliberately NOT here yet

Per the spec's MVP section: no Real-World Opportunity Engine, no social
layer, no complex economy, no multiplayer. Those are Phase 3+.
