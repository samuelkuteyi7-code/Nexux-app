"""
Simulation Engine - Section 9 & 10 of the Master Spec.

CORE PRINCIPLE FROM THE SPEC: "AI should not be the sole authority for
numerical outcomes." This module owns every numeric state change.
The AI layer (see app/ai/) only generates narrative text - situations,
character dialogue, flavor - and NEVER decides numbers directly. It
can *suggest* a delta, but this engine applies deterministic rules
and clamps to sane bounds.

Conceptual model (spec section 9):
    Current State + User Decision + Event + Simulation Rules -> New State
"""

from copy import deepcopy
from typing import Any


DEFAULT_STATE = {
    "time_step": 0,
    "resources": {"money": 1000, "energy": 100},
    "skills": {},
    "relationships": {},
    "log": [],
}


def new_world_state(starting_skills: dict[str, int] | None = None) -> dict[str, Any]:
    """Create the initial state for a freshly generated world."""
    state = deepcopy(DEFAULT_STATE)
    if starting_skills:
        state["skills"] = dict(starting_skills)
    return state


def clamp(value: int, low: int = 0, high: int = 100) -> int:
    return max(low, min(high, value))


def apply_decision(state: dict[str, Any], choice_effects: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
    """
    Apply a decision's effects to world state under fixed rules.

    choice_effects example:
        {
            "skills": {"coding": +5},
            "resources": {"money": -200, "energy": -10},
            "log_entry": "You enrolled in an evening coding course."
        }

    Returns (new_state, applied_delta) so callers/tests can see exactly
    what changed - this is the audit trail stored on Decision.state_delta.
    """
    new_state = deepcopy(state)
    applied: dict[str, Any] = {"skills": {}, "resources": {}}

    for skill, delta in choice_effects.get("skills", {}).items():
        current = new_state["skills"].get(skill, 0)
        updated = clamp(current + delta)
        applied["skills"][skill] = updated - current
        new_state["skills"][skill] = updated

    for resource, delta in choice_effects.get("resources", {}).items():
        current = new_state["resources"].get(resource, 0)
        updated = max(0, current + delta)  # resources don't clamp to 100, just floor at 0
        applied["resources"][resource] = updated - current
        new_state["resources"][resource] = updated

    new_state["time_step"] += 1

    log_entry = choice_effects.get("log_entry", "A decision was made.")
    new_state["log"].append({"step": new_state["time_step"], "entry": log_entry})

    return new_state, applied


def project_whatif(state: dict[str, Any], hypothetical_effects: dict[str, Any], steps: int = 1) -> dict[str, Any]:
    """
    Run a hypothetical forward WITHOUT mutating the real world state.
    Used by the What If? engine (spec section 11). The result is a
    projection to compare against the current path - never merged back
    unless the user explicitly commits to it as a real decision.
    """
    projected = deepcopy(state)
    for _ in range(steps):
        projected, _ = apply_decision(projected, hypothetical_effects)
    return projected
