# NEXUS MVP — Architecture Notes

Maps directly to Master Spec sections 7–10.

## Flow

```
UserProfile (section 7.1)
     │
     ▼
World generated (section 8) — one goal, starting state
     │
     ▼
narrative.generate_situation()  ──►  AI/narrative layer (section 6, 10)
     │  returns situation + option effects (proposed, not applied)
     ▼
User picks an option (frontend)
     │
     ▼
engine.apply_decision()  ──►  Simulation layer (section 9, 10)
     │  the ONLY place state numbers change; deterministic + clamped
     ▼
World.state updated, Decision logged (audit trail)
```

## Why AI and simulation are separate modules

Spec section 10: *"This separation reduces the risk of an AI inventing
inconsistent consequences simply to produce an entertaining response."*

Concretely: `narrative.py` can propose an effects dict (e.g. `{"skills":
{"coding": 5}, "resources": {"money": -200}}`), but it never touches the
database or applies the change itself. `engine.py` owns clamping, floors,
and the actual mutation. This means:

- Numbers stay internally consistent even as narrative generation improves
  or gets swapped for a real LLM call.
- You can unit-test the simulation rules without any AI involved.
- Swapping the narrative source (templates → Claude API → something else)
  never risks corrupting world state.

## What If? branches

`WhatIfBranch` rows store a **projection** — `engine.project_whatif()` runs
the same rules forward on a *copy* of state, never the real one. Nothing
is committed unless the user turns a hypothetical into a real decision via
`/decision/`.

## Data model

- `UserProfile` — section 7.1, MVP fields only (no CV/financial yet)
- `World` — section 8, one per user for now (MVP = single active world)
- `Decision` — section 9, the audit trail of real state changes
- `WhatIfBranch` — section 11, hypothetical projections

## Next architectural steps (post-MVP, per spec roadmap)

- Phase 2: multiple concurrent worlds, persistent AI characters with memory
- Phase 3: Real-World Opportunity Engine — separate service, reads actual
  CV/profile data, never touches simulation state (spec section 14 is
  explicit that this must stay separate from fictional events)
- Move `state` JSON blob into normalized tables once the shape stabilizes
- Swap SQLite → Postgres by changing `DATABASE_URL` only
